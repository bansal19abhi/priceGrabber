package com.example.macstudent.pricegrabber;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LocationActivity extends AppCompatActivity implements View.OnClickListener{


    Button btnWallmart , btnFoodbasic, btnNoFrills ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnWallmart.getId()){
            String geoUri;

            geoUri = "http://maps.google.com/maps?q=loc:" +
                    13.7733 + "," + 79.3360 + " (" + "Walmart" + ")";
            Intent locationIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoUri));

        }else if (view.getId() == btnFoodbasic.getId()){
            String geoUri;

            geoUri = "http://maps.google.com/maps?q=loc:" +
                    43.7733 + "," + 79.3360 + " (" + "Food Basics" + ")";
            Intent locationIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoUri));

        }else if (view.getId() == btnNoFrills.getId()){
            String geoUri;

            geoUri = "http://maps.google.com/maps?q=loc:" +
                    73.7733 + "," + 79.3360 + " (" + "No Frills" + ")";
            Intent locationIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoUri));

        }
    }
}
