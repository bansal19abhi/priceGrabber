package com.example.macstudent.pricegrabber;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class PcActivity extends AppCompatActivity implements View.OnClickListener {



    Spinner spnStore;

    String store[] = {"Wallmart","NoFrills","FoodBasics"};

    String selectedStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pc);

        /*spnStore = findViewById(R.id.spnStore);
        ArrayAdapter storeAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, store);
        storeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnStore.setAdapter(storeAdapter);
        spnStore.setOnItemSelectedListener(this);*/

    }


    @Override
    public void onClick(View view) {

    }
}
