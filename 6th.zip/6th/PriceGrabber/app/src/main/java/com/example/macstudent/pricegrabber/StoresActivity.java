package com.example.macstudent.pricegrabber;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class StoresActivity extends AppCompatActivity implements View.OnClickListener {

    RadioGroup radioGroup;
    RadioButton wallmart, food_basics, fresh_co, no_frills;
    TextView textView;
    Button select_option;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stores);

        wallmart = findViewById(R.id.wallmart);
        //View.OnClickListener(this)
        food_basics = findViewById(R.id.food_basics);
        //View.OnClickListener(this)
        fresh_co = findViewById(R.id.fresh_co);
        //View.OnClickListener(this)
        no_frills = findViewById(R.id.no_frills);
        //View.OnClickListener(this)

        //textView = findViewById(R.id.s)
    }

    @Override
    public void onClick(View view) {
        if (wallmart.isChecked()) {
            //select_option = findViewById(R.id.);           wallmart_database
            //select_option.setOnClickListener(this);

        } else if (food_basics.isChecked()) {
            //select_option = findViewById(R.id.);           food_basics_database
            //select_option.setOnClickListener(this);

        } else if (fresh_co.isChecked()) {
            //select_option = findViewById(R.id.);           fresh_co_database
            //select_option.setOnClickListener(this);

        } else if (no_frills.isChecked()) {
            //select_option = findViewById(R.id.);           no_frills_database
            //select_option.setOnClickListener(this);

        }
    }
}