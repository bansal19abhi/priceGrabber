package com.example.macstudent.pricegrabber;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LocationActivity extends AppCompatActivity implements View.OnClickListener{


    Button btnWallmart , btnFoodbasic, btnNoFrills ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnWallmart.getId()){
            String geoUri;

            geoUri = "http://maps.google.com/maps?q=loc:" +
                    43.7733 + "," + 79.3360 + " (" + "Cestar College" + ")";

        }
    }
}
