package com.example.macstudent.pricegrabber;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

public class PcActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {



    Spinner spnStore, spnProduct;
    TextView txtAmount;
    String store[] = {"Wallmart","NoFrills","FoodBasics"};
    String product[] = {"Milk","Bread","Butter","Cheese","Maggi","Cookies","Chips","Eggs","Yogurt","Chicken","Muffins","Chocolates"};
    int productRate[] = {10,20,1,5,6,7,2,13,11,9};
    String selectedStore, selectedProduct;

    RadioButton rdo1, rdo2, rdo3, rdo4, rdo5, rdo6, rdo7, rdo8, rdo9, rdo10;
    Button btnAddFavorite;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pc);

        spnStore = findViewById(R.id.spnStore);
        ArrayAdapter storeAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, store);
        storeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnStore.setAdapter(storeAdapter);
        spnStore.setOnItemSelectedListener(this);

        spnProduct = findViewById(R.id.spnProduct);
        ArrayAdapter productAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, product);
        productAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnProduct.setAdapter(productAdapter);
        spnProduct.setOnItemSelectedListener(this);


        btnAddFavorite = findViewById(R.id.btnAddFavorite);
        btnAddFavorite.setOnClickListener(this);


    }


    @Override
    public void onClick(View view) {


        if (btnAddFavorite.getId() == view.getId()){
            SharedPreferences sp = getSharedPreferences("com.example.macstudent.login.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("Store", selectedStore);

            edit.putInt("Amount", Integer.parseInt(txtAmount.getText().toString().substring(1)));

            edit.commit();

            startActivity(new Intent(getApplicationContext(), FavoritesActivity.class));
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        if(adapterView.getId() == spnStore.getId()){
            selectedStore = store[position];
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
